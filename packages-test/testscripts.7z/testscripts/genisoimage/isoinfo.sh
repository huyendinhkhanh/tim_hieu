#!/bin/bash

#==============================================================================
# DESCRIPTION: Testing for isoinfo command.
#              Read an ISO-9660 image (cd.iso) from SCSI
#              target and print information from the primary volume descriptor.
#==============================================================================

check=0
echo "Testing isoinfo" > ${log_file}

# Read "cd.iso" image.
isoinfo -d -i ${data_dir}/cd.iso >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Check result of testcase
assert_passed $check 0

