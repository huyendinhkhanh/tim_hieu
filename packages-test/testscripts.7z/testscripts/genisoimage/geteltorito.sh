#!/bin/bash

#==============================================================================
# DESCRIPTION: Testing for geteltorito command.
#              Extract an El Torito image from a bootable CD 
#	       (debian-8.10.0-arm64-netinst.iso) and write the data extracted to
#              a file.
#==============================================================================

check=0
echo "Testing geteltorito" > ${log_file}

# Extract "debian-8.10.0-arm64-netinst.iso" CD and write data to "eltorito" file.
geteltorito -o eltorito ${data_dir}/debian-8.10.0-arm64-netinst.iso >> ${log_file} 2>&1
ls eltorito >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Check result of testcase
assert_passed $check 0

rm -f eltorito 
