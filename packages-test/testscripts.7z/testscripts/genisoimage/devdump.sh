#!/bin/bash

#==============================================================================
# DESCRIPTION: Testing for devdump command.
#              Display the contents of "cd.iso" image. The initial screen is a 
#              display of the first 256 bytes of the first 2048 byte sector
#==============================================================================

check=0
echo "Testing devdump" > ${log_file}

# Display the contents of "cd.iso" image.
script -q -c "devdump -i ${data_dir}/cd.iso" >> ${log_file} 2>&1 << EOF
q
EOF
cat ${log_file} | grep "Zone, zone offset:" >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Check result of testcase
assert_passed $check 0

rm -f typescript
