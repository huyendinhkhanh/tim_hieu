#!/bin/bash

#==============================================================================
# DESCRIPTION: Testing for dirsplit command.
#              Split "sampledir" folder containing thousands of files totaling 
#              up to more than 10MB into individual directories of 10 MB each.
#==============================================================================

check=0
echo "Testing dirsplit" > ${log_file}

# Split "sampledir" folder.
dirsplit --size 10M --expmode 1 ${data_dir}/sampledir/ >> ${log_file} 2>&1
ls vol_1.list vol_2.list >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Check result of testcase
assert_passed $check 0

rm -f vol_1.list vol_2.list 
