#!/bin/bash

#==============================================================================
# DESCRIPTION: Testing for isovfy command.
#              Verify the integrity of the specified ISO9660 image (cd.iso) and 
#              write the results to standard output.
#==============================================================================

check=0
echo "Testing isovfy" > ${log_file}

# Verify the integrity of the "cd.iso".
isovfy -i ${data_dir}/cd.iso >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Check result of testcase
assert_passed $check 0

