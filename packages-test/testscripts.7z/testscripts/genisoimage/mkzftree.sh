#!/bin/bash

#==============================================================================
# DESCRIPTION: Testing for mkzftree command.
#              Create a zisofs/RockRidge compressed file tree for "sampledir" directory.
#==============================================================================

check=0
echo "Testing mkzftree" > ${log_file}

# Create a zisofs/RockRidge compressed file tree for "sampledir" directory.
mkzftree -p 9 --one-filesystem ${data_dir}/sampledir/ compressedft >> ${log_file} 2>&1
ls compressedft >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Check result of testcase
assert_passed $check 0

rm -rf compressedft 
