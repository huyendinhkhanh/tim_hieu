#!/bin/bash

#==============================================================================
# DESCRIPTION: Testing for mcelog command.
#              Start, stop and restart mcelog service then check result.
#==============================================================================

check=0
echo "Testing mcelog" > ${log_file}

# Start mcelog service
systemctl start mcelog >> ${log_file} 2>&1
systemctl status -l mcelog | grep "Active: active (running)" >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

#Wait till job finishes
sleep 2

# Stop mcelog service
systemctl stop mcelog >> ${log_file} 2>&1
systemctl status -l mcelog | grep "Active: inactive (dead)" >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Wait till job finishes
sleep 2

# Restart mcelog service
systemctl restart mcelog >> ${log_file} 2>&1
systemctl status -l mcelog | grep "Active: active (running)" >> ${log_file} 2>&1
if [ $? -ne 0 ]; then
  check=1
fi

# Wait till job finishes
sleep 2

# Check result of testcase
assert_passed $check 0

